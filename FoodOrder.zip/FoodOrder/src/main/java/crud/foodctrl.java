package crud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class foodctrl
 */
@WebServlet("/foodctrl")
public class foodctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public foodctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String pizza1 = request.getParameter("pizza1");
		String burger1 = request.getParameter("burger1");
		String basundi1 = request.getParameter("basundi1");
		String noodle1 = request.getParameter("noodle1");
		String naan1 = request.getParameter("naan1");
		String rice1 = request.getParameter("rice1");
		String sbc1 = request.getParameter("sbc1");
		String vb1 = request.getParameter("vb1");
		String manchurian1 = request.getParameter("manchurian1");
		
		foodpojo fod = new foodpojo( pizza1, burger1,  basundi1,  noodle1,  naan1, rice1,
				 sbc1, vb1, manchurian1);
		daoall dall = new daoall();
		String str =dall.foinsert(fod);
		
		   if(str.equals("success" ))
			{
				RequestDispatcher rd = request.getRequestDispatcher("foodregi.jsp");
				rd.forward(request, response);
			}
			else
			{
				
	   			pw.print("something went wrong");
			
			}
	
	}

}
