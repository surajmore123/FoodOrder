package crud;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class daoall {
	
	// for registration
	public String insert(userpojo upojo)
	{
		Session s = new Configuration().configure().buildSessionFactory().openSession();
		Transaction t = s.beginTransaction();
		s.save(upojo);
		t.commit();
		s.close();
		return "success";
	}
	 // for validation
	public String validation(String email, String pwd )
	{
		
		Session s = new Configuration().configure().buildSessionFactory().openSession();
		Transaction t = s.beginTransaction();
		//String hql = "from member where  email = :v1 and pwd = :v2";
		userpojo upojo = null;
		
		//   !!!!!!   always take class name as table name in this query    !!!!!!
		upojo = (userpojo) s.createQuery("from userpojo u where u.email = :email").setParameter("email", email).uniqueResult();
		
		t.commit();
		s.close();
		if(upojo!=null  && upojo.getPwd().equals(pwd))
		{
			return "success";
		}
		else
		{
			return "error";
		}
		      
	}
	
	// feedback insert
	
		 public String finsert(feedback fd)
	     {
			Session s = new Configuration().configure().buildSessionFactory().openSession();
			Transaction t = s.beginTransaction();
			s.save(fd);
			t.commit();
			s.close();
			return "success";
	     }
		 
		 // food insert
		 public String foinsert(foodpojo fod)
		 {
			 
		 Session s = new Configuration().configure().buildSessionFactory().openSession();
		 Transaction t = s.beginTransaction();
		 s.save(fod);
		 t.commit();
		 s.close();
		 return "success";
		 
		 }
		 
		  // food insert individual   **currently not in use**
		
		public String indinsert (String pizza1, String burger1, String basundi1, String noodle1, String naan1, String rice1,
				String sbc1, String vb1, String manchurian1)
		 {
			//foodpojo fod = null;
			//if(fod!=null && fod.getPizza1().equals(pizza1))
			//{
			 Session s = new Configuration().configure().buildSessionFactory().openSession();
			 Transaction t = s.beginTransaction();
			 String hql = "insert into foodpojo1 (pizza1)"+"select pizza1 from foodpojo";
			 Query q = s.createQuery(hql);
			 q.executeUpdate();
			 t.commit();
			 s.close();
			// return "success";
		//	}
	     	//return pizza1;
			 return "success";
			
		 }
		 
		// insert of payment
		public String payinsert(payment pay)
		{
			Session s = new Configuration().configure().buildSessionFactory().openSession();
			Transaction t = s.beginTransaction();
			s.save(pay);
			t.commit();
			s.close();
			return "success";
			
		}
		
		// insert into order food
		public String orderinsert(order o)
		{
			Session s = new Configuration().configure().buildSessionFactory().openSession();
			Transaction t = s.beginTransaction();
			s.save(o);
			t.commit();
			s.close();
			return "success";
		}
		
		// show all orders
		
	 
	@SuppressWarnings("unchecked")
	public List<order> getallorder()
	  {
		  List<order> l = null;
		  Session s = new Configuration().configure().buildSessionFactory().openSession();
		  Transaction t = s.beginTransaction();
		  l = (List<order>) s.createQuery("from order").list();
		  t.commit();
		  s.close();
		  return l;
	  }
	
	// delete order by id
	public String delete(int id)
	{
		Session s = new Configuration().configure().buildSessionFactory().openSession();
		Transaction t = s.beginTransaction();
		order o = (order) s.get(order.class, id);
		s.delete(o);
		t.commit();
		s.close();
		return "success";
	}
	
	// update order by id
	
	public order getorderbyid(int id)
	{
		Session s = new Configuration().configure().buildSessionFactory().openSession();
		Transaction t = s.beginTransaction();
		order o = null;
		 o = (order) s.get(order.class, id);
		t.commit();
		s.close();
		return o;
		
	}
	
	// for update 
	public String update(order o)
	{
		Session s = new Configuration().configure().buildSessionFactory().openSession();
		Transaction t = s.beginTransaction();
		s.update(o);
		t.commit();
		s.close();
		return "success";
	}
	

}
