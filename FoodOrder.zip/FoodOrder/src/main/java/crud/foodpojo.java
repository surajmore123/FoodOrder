package crud;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "food")
public class foodpojo {
	
	@Id
	private String pizza1;
	private String burger1;
	private String basundi1;
	private String noodle1;
	private String naan1;
	private String rice1;
	private String sbc1;
	private String vb1;
	private String manchurian1;
	
	public foodpojo()
	{
		
	}

	public foodpojo(String pizza1, String burger1, String basundi1, String noodle1, String naan1, String rice1,
			String sbc1, String vb1, String manchurian1) {
		super();
		this.pizza1 = pizza1;
		this.burger1 = burger1;
		this.basundi1 = basundi1;
		this.noodle1 = noodle1;
		this.naan1 = naan1;
		this.rice1 = rice1;
		this.sbc1 = sbc1;
		this.vb1 = vb1;
		this.manchurian1 = manchurian1;
	}
	

	public String getPizza1() {
		return pizza1;
	}

	public void setPizza1(String pizza1) {
		this.pizza1 = pizza1;
	}

	public String getBurger1() {
		return burger1;
	}

	public void setBurger1(String burger1) {
		this.burger1 = burger1;
	}

	public String getBasundi1() {
		return basundi1;
	}

	public void setBasundi1(String basundi1) {
		this.basundi1 = basundi1;
	}

	public String getNoodle1() {
		return noodle1;
	}

	public void setNoodle1(String noodle1) {
		this.noodle1 = noodle1;
	}

	public String getNaan1() {
		return naan1;
	}

	public void setNaan1(String naan1) {
		this.naan1 = naan1;
	}

	public String getRice1() {
		return rice1;
	}

	public void setRice1(String rice1) {
		this.rice1 = rice1;
	}

	public String getSbc1() {
		return sbc1;
	}

	public void setSbc1(String sbc1) {
		this.sbc1 = sbc1;
	}

	public String getVb1() {
		return vb1;
	}

	public void setVb1(String vb1) {
		this.vb1 = vb1;
	}

	public String getManchurian1() {
		return manchurian1;
	}

	public void setManchurian1(String manchurian1) {
		this.manchurian1 = manchurian1;
	}


	
	

}
