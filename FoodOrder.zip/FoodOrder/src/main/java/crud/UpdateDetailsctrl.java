package crud;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class UpdateDetailsctrl
 */
@WebServlet("/UpdateDetailsctrl")
public class UpdateDetailsctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateDetailsctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String sid = request.getParameter("id");
		int id = Integer.parseInt(sid);
     	daoall  dall = new daoall();
    	order o =dall.getorderbyid(id);
    	pw.print("<link rel='stylesheet' type='text/css' href='order.css'>");
     	pw.print("<body>");
        pw.print("<header>");
            pw.print("<h1>Update Form</h1>");
           pw.print("<nav>");
               pw.print("<ul>");
                    pw.print("<li><a href='frontpage.jsp'>Home</a></li>");
                    pw.print("<li><a href='index1.jsp'>Menu</a></li>");
                    pw.print("<li><a href='logOutctrl'>logOut</a></li>");
                    
                pw.print("</ul>");
                pw.print("</nav>");
                pw.print("</header>") ;
                pw.print("<section class='order-form'>");
                pw.print("<form action='UpdateDetailsctrl2'>");
                pw.print("<input type='hidden' id='id' name='id' value = '"+o.getId()+"'><br><br>");
                pw.print("<label for='name'>Name:</label>");
                pw.print("<input type='text' id='name' name='name' value = '"+o.getName()+"'><br><br>");
              
                pw.print("<label for='name'>Email:</label>");
                pw.print("<input type='text' id='email' name='email' value = '"+o.getEmail()+"'><br><br>");
                
                pw.print("<label for='phone'>Phone:</label>");
                pw.print("<input type='number' id='phone' name='phone' value = '"+o.getPhone()+"'><br><br>");
                
                pw.print("<label for='address'>Address:</label>");
                pw.print("<textarea id='address' name='address' value = '"+o.getAddress()+"'></textarea><br><br>");
               
                pw.print("<label for='meal_type'>Meal:</label>");
                pw.print("<select id='meal_type' name='meal_type' value = '"+o.getMeal_type()+"' >");
                                    pw.print("<option>Select</option>");
                                    pw.print("<option>Pizza</option>");
                                    pw.print("<option>Burger</option>");
                                    pw.print("<option>Basundi</option>");
                                    pw.print("<option>Noodle</option>");
                                    pw.print("<option>Naan</option>");
                                    pw.print("<option>Rice</option>");
                                    pw.print("<option>Starbuck</option>");
                                    pw.print("<option>Veg Biryani</option>");
                                    pw.print("<option>Manchurian</option>");               
                pw.print("</select><br><br>");
                pw.print("<label for='meal_quantity'>Meal Quantity:</label>");
                pw.print("<input type='number' id='meal_quantity' name='meal_quantity' value = '"+o.getMeal_quantity()+"'><br><br>");
                pw.print("<label for='total_price'>Total Price:</label>");
               pw.print("<input type='text' id='total_price' name='total_price' value = '"+o.getTotal_price()+"'><br><br> ");   //   <!-- readonly     meal quantity * totalprice-->   
               pw.print("<input type='submit' value='submit'>");
            pw.print("</form>");
       pw.print("</section>");
        
    pw.print("</body>");
		
	
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
