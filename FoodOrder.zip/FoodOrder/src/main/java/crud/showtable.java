package crud;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class showtable
 */
@WebServlet("/showtable")
public class showtable extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public showtable() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		daoall  dall  = new daoall();
		List<order>l = dall.getallorder();
		pw.print("<link rel='stylesheet' type='text/css' href='showtables.css'>");
		pw.print("<body>");
		pw.print("<header>");
		pw.print("<h1> Your Order's </h1>");
		pw.print("</header>");
		pw.print("<table border=5>");
						 		pw.print("<tr>");
						 			pw.print("<th>ID</th>");
						 			pw.print("<th>Name</th>");
						 			pw.print("<th>Email</th>");
						 			pw.print("<th>Phone</th>");
						 			pw.print("<th>Address</th>");
						 			pw.print("<th>meal_type</th>");
						 			pw.print("<th>meal_quantity</th>");
						 			pw.print("<th>total_price</th>");
						 			pw.print("<th>Action</th>");
						 			
		for(order o : l)
		{
			pw.print("<tr><td>"+o.getId() +"</td><td>"+o.getName() +"</td><td>"+o.getEmail() +"</td><td>"+o.getPhone()+"</td><td>"+o.getAddress()+"</td><td>"+o.getMeal_type()+"</td><td>"+o.getMeal_quantity()+"</td><td>"+o.getTotal_price()+"</td><td><a href='UpdateDetailsctrl?id="+o.getId()+"'>UPDATE</a></td>  <td><a href='deletectrl?id="+o.getId()+"'>DELETE</a></td></tr>");
			pw.print("<br>");
		}
		
		pw.print("</table>");
		pw.print("</body>");

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
