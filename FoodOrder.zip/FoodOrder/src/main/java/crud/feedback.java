package crud;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "fb")
public class feedback {
	
	@Id
	private String name;
	private String email;
	private String discription;
	
	
	public feedback()
	{
		
	}


	public feedback(String name, String email, String discription) {
		super();
		this.name = name;
		this.email = email;
		this.discription = discription;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getEmail() {
		return email;
	}


	public void setEmail(String email) {
		this.email = email;
	}


	public String getDiscription() {
		return discription;
	}


	public void setDiscription(String discription) {
		this.discription = discription;
	}

	
}
