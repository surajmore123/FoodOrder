package crud;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class orderctrl
 */
@WebServlet("/orderctrl")
public class orderctrl extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public orderctrl() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		String address = request.getParameter("address");
		String meal_type = request.getParameter("meal_type");
		String meal_quantity = request.getParameter("meal_quantity");
		String total_price = request.getParameter("total_price");
		
		order o = new order( name,  email, phone,  address, meal_type, meal_quantity, total_price);
		daoall dall = new daoall();
		String str = dall.orderinsert(o);
		
		if(str.equals("success" ))
		{
			RequestDispatcher rd = request.getRequestDispatcher("onlinepayment.jsp");
			rd.forward(request, response);
		}
		else
		{
			pw.print("something went wrong");
			RequestDispatcher rd = request.getRequestDispatcher("order.jsp");
			rd.include(request, response);
		
		}
		
	}

}
